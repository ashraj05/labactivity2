#!/bin/bash

filename="$1"
# Find the file
file_path=$(find / -type f -name "$filename" 2>/dev/null)

if [ -n "$file_path" ]; then
  echo "File found: $file_path"
else
  echo "File '$filename' not found."
fi

cat filename | head -n 4
