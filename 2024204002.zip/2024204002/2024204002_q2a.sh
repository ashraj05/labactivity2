#!/bin/bash

echo -n
read n

x=0
y=1

echo -n "$x $y "

for (( i=2; i<$n; i++ ))
do
    z=$((x + y))
    echo -n "$z "
    x=$y
    y=$z
done
