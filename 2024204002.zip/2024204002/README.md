1. for 2024204002_q1.sh, I created a file named john_doe_assignment.txt
I passed the file as first argument
I find the file using file_path=$(find / -type f -name "$filename" 2>/dev/null)
then I check if the file_path is there or not.
2. for 2024204002_q2a.sh, I used for loop as follows:
a=0
b=1

echo -n "$a $b "
for (( i=2; i<$n; i++ ))
do
    c=$((a + b))
    echo -n "$c "
    a=$b
    b=$c
done
3. for 2024204002_q2b.sh, I used export to read the variable and then add them.
