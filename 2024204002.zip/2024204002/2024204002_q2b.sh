#!/bin/bash
export A=10
export B=11
sum=$(($A+$B))
echo "Sum of $A and $B is: $sum"


